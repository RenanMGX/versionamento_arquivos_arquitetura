import os
from patrimar_dependencies.sharepointfolder import SharePointFolders
sharepoint_path = SharePointFolders(r'RPA - Dados\Configs\versionamento arquivos ConstruCode').value
if not sharepoint_path:
    raise FileExistsError(f"O caminho do Sharepoint '{sharepoint_path}' não foi encontrado!")
os.environ['json_folders_path'] = sharepoint_path
from Entities.files_manipulation import FilesManipulation

if __name__ == "__main__":
    bot = FilesManipulation(base_path=r'\\server008\G\ARQ_PATRIMAR\Setores\dpt_tecnico\projetos_arquitetura\_ARQUITETURA')
    print(bot.find_empreendimento("E062"))
    print(bot.find_empreendimento("A052"))
    print(bot.find_empreendimento("A042"))

    